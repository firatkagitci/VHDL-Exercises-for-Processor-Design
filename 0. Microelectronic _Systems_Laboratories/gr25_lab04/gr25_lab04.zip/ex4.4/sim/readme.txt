opcode is unsigned
cw is hexadecimal
func_for_decode is unsigned
ir_opcode is unsigned