Just to be sure, we added a folder with all the files generated during the lab, in case something misses in this main folder problably is in the folder 
named "other files"